# -*- coding: utf-8 -*-
"""
Created on Thu Dec 14 11:42:51 2023

@author: lwx
"""

import numpy as np
import random
import matplotlib.pyplot as plt
from scipy.interpolate import griddata

M = 1.0 
m = 0.1  
l = 0.5  
mu_c = 0.0005 
mu_p = 0.000002 
g = -9.8  
dt = 0.02

theta_bins = np.array([-12, -6, -1, 0, 1, 6, 12]) * np.pi / 180  
x_bins = [-2.4, -0.8, 0.8, 2.4] 
theta_dot_bins = np.array([-np.inf, -50, 50, np.inf]) * np.pi / 180  
x_dot_bins = [-np.inf, -0.5, 0.5, np.inf]  

actions = [-10, 10]
num_states = 6334


def range_of_region(region_index):
    theta_index = np.floor(region_index/1000)
    x_index = np.floor((region_index - 1000*theta_index)/100)
    theta_dot_index = np.floor((region_index - 1000*theta_index - 100*x_index)/10)
    x_dot_index = region_index - 1000*theta_index - 100*x_index - 10*theta_dot_index
    
    if theta_index == 1:
        theta_range = (-12*np.pi/180,-6*np.pi/180)
    elif theta_index == 2:
        theta_range = (-6*np.pi/180,-1*np.pi/180)
    elif theta_index == 3:
        theta_range = (-1*np.pi/180,0*np.pi/180)
    elif theta_index == 4:
        theta_range = (0*np.pi/180,1*np.pi/180)
    elif theta_index == 5:
        theta_range = (1*np.pi/180,6*np.pi/180)
    elif theta_index == 6:
        theta_range = (6*np.pi/180,12*np.pi/180)
    
    if x_index == 1:
        x_range = (-2.4,-0.8)
    elif x_index == 2:
        x_range = (-0.8,0.8)
    elif x_index == 3:
        x_range = (0.8,2.4)

    if theta_dot_index == 1:
        theta_dot_range = (-1200*np.pi/180,-50*np.pi/180)
    elif theta_dot_index == 2:
        theta_dot_range = (-50*np.pi/180,50*np.pi/180)
    elif theta_dot_index == 3:
        theta_dot_range = (50*np.pi/180,1200*np.pi/180)

    if x_dot_index == 1:
        x_dot_range = (-240, -0.5)
    elif x_dot_index == 2:
        x_dot_range = (-0.5, 0.5)
    elif x_dot_index == 3:
        x_dot_range = (0.5, 240)
    
    return theta_range, x_range, theta_dot_range, x_dot_range

def generate_random_point(region_index,Number_of_points):
    theta_range, x_range, theta_dot_range, x_dot_range = range_of_region(region_index)
    
    theta_list = [random.uniform(*theta_range) for _ in range(Number_of_points)]
    x_list = [random.uniform(*x_range) for _ in range(Number_of_points)]
    theta_dot_list = [random.uniform(*theta_dot_range) for _ in range(Number_of_points)]
    x_dot_list = [random.uniform(*x_dot_range) for _ in range(Number_of_points)]
    
    random_points=np.zeros((Number_of_points,4))
    for i in range(Number_of_points):
        random_points[i,:]=np.array([theta_list[i],x_list[i],theta_dot_list[i],x_dot_list[i]])

    return random_points    

def discretize_state(theta, x, theta_dot, x_dot):
    theta_bin = np.digitize(theta, theta_bins)
    x_bin = np.digitize(x, x_bins)
    theta_dot_bin = np.digitize(theta_dot, theta_dot_bins)
    x_dot_bin = np.digitize(x_dot, x_dot_bins)
    
    return theta_bin*1000 + x_bin*100 + theta_dot_bin*10 + x_dot_bin

def dynamics(theta, x, theta_dot, x_dot, F):
    theta_ddot = (g * np.sin(theta) + np.cos(theta) * (-F - m*l*theta_dot**2 * np.sin(theta) + mu_c * np.sign(x_dot)) / (M + m) - (mu_p * theta_dot / m / l)) / \
                   (l * (4/3 - m * np.cos(theta)**2 / (M + m)))
    x_ddot = (F + m*l*(theta_dot**2 * np.sin(theta) - theta_ddot * np.cos(theta)) - mu_c*np.sign(x_dot)) / (M + m)
    
    return theta_ddot, x_ddot

def update_state(theta, x, theta_dot, x_dot, F, dt):
    theta_ddot, x_ddot = dynamics(theta, x, theta_dot, x_dot, F)
    new_theta = theta + theta_dot * dt
    new_x = x + x_dot * dt
    new_theta_dot = theta_dot + theta_ddot * dt
    new_x_dot = x_dot + x_ddot * dt
    return new_theta, new_x, new_theta_dot, new_x_dot

def is_terminal(theta, x):
    
    return theta < -12*np.pi/180 or theta > 12*np.pi/180 or x < -2.4 or x > 2.4

def transition_probability(random_points, dt):
    
    pb = np.zeros((6334,2))
    for i in range(len(random_points)):
        theta, x, theta_dot, x_dot = random_points[i,:]
        
        for a in range(len(actions)):
            action = actions[a]
            
            new_theta, new_x, new_theta_dot, new_x_dot = update_state(theta, x, theta_dot, x_dot, action, dt)
            if is_terminal(new_theta,new_x):        
                pb[0,a] += 1
            else:
                new_index = discretize_state(new_theta, new_x, new_theta_dot, new_x_dot)
                pb[new_index,a] += 1
            
    pb /= len(random_points)
    
    return pb
        
policy = np.random.choice(actions, size=num_states)
value_function = np.zeros(num_states)

tp = np.zeros((num_states, num_states, 2))
for s in range(num_states):
    theta_index = np.floor(s/1000)
    x_index = np.floor((s - 1000*theta_index)/100)
    theta_dot_index = np.floor((s - 1000*theta_index - 100*x_index)/10)
    x_dot_index = s - 1000*theta_index - 100*x_index - 10*theta_dot_index
    
    if theta_index < 1 or theta_index > 6 or x_index < 1 or x_index > 3 or theta_dot_index < 1 or theta_dot_index > 3 \
        or x_dot_index < 1 or x_dot_index > 3: 
            continue
    
    rp = generate_random_point(s,10000)
    tp[s,:,:] = transition_probability(rp, dt)

# Policy iteration loop
is_policy_stable = False
iterations = 0
delta_threshold = 1e-4
while not is_policy_stable:
    iterations += 1
    print('iteration=',iterations)
    
    # Policy Evaluation
    while True:
        delta = 0
        for s in range(num_states):
            
            theta_index = np.floor(s/1000)
            x_index = np.floor((s - 1000*theta_index)/100)
            theta_dot_index = np.floor((s - 1000*theta_index - 100*x_index)/10)
            x_dot_index = s - 1000*theta_index - 100*x_index - 10*theta_dot_index
            
            if theta_index < 1 or theta_index > 6 or x_index < 1 or x_index > 3 or theta_dot_index < 1 or theta_dot_index > 3 \
                or x_dot_index < 1 or x_dot_index > 3: 
                    continue
            
            v = value_function[s]
            new_value = 0
            aa = actions.index(policy[s])
            for i in range(num_states-1):
                new_value += tp[s,i+1,aa]*(1+value_function[i+1])
            delta = max(delta, np.abs(v - new_value))
            value_function[s] = new_value
            
        if delta < delta_threshold:  
            break       
            
    # Policy Improvement
    is_policy_stable = True
    for s in range(num_states):
        theta_index = np.floor(s/1000)
        x_index = np.floor((s - 1000*theta_index)/100)
        theta_dot_index = np.floor((s - 1000*theta_index - 100*x_index)/10)
        x_dot_index = s - 1000*theta_index - 100*x_index - 10*theta_dot_index
        
        if theta_index < 1 or theta_index > 6 or x_index < 1 or x_index > 3 or theta_dot_index < 1 or theta_dot_index > 3 \
            or x_dot_index < 1 or x_dot_index > 3: 
                continue

        old_action = policy[s]
        new_action_values = np.zeros((2,1))
        
        new_value = 0
        for i in range(num_states-1):
            new_value += tp[s,i+1,0]*(1+value_function[i+1])
        new_action_values[0] = new_value
        new_value = 0
        for i in range(num_states-1):
            new_value += tp[s,i+1,1]*(1+value_function[i+1])
        new_action_values[1] = new_value
        
        policy[s] = actions[np.argmax(new_action_values)]
        if old_action != policy[s]:
            is_policy_stable = False
    
    if iterations > 1000:  
        print("Stopping due to too many iterations")
        break

#%% Post-Processing
def at_which_point(region_index):
    theta_index = np.floor(region_index/1000)
    x_index = np.floor((region_index - 1000*theta_index)/100)
    theta_dot_index = np.floor((region_index - 1000*theta_index - 100*x_index)/10)
    x_dot_index = region_index - 1000*theta_index - 100*x_index - 10*theta_dot_index
    
    if theta_index == 1:
        theta = -12*np.pi/180
    elif theta_index == 2:
        theta = -3.5*np.pi/180
    elif theta_index == 3:
        theta = -0.5*np.pi/180
    elif theta_index == 4:
        theta = 0.5*np.pi/180
    elif theta_index == 5:
        theta = 3.5*np.pi/180
    elif theta_index == 6:
        theta = 12*np.pi/180
    
    if x_index == 1:
        x = -2.4
    elif x_index == 2:
        x = 0.0
    elif x_index == 3:
        x = 2.4

    if theta_dot_index == 1:
        theta_dot = -625*np.pi/180
    elif theta_dot_index == 2:
        theta_dot = 0
    elif theta_dot_index == 3:
        theta_dot = 625*np.pi/180

    if x_dot_index == 1:
        x_dot = -120.25
    elif x_dot_index == 2:
        x_dot = 0
    elif x_dot_index == 3:
        x_dot = 120.25

    return theta, x, theta_dot, x_dot

results = []
i = 0
results = np.zeros((162,5))
for s in range(num_states):
    theta_index = np.floor(s/1000)
    x_index = np.floor((s - 1000*theta_index)/100)
    theta_dot_index = np.floor((s - 1000*theta_index - 100*x_index)/10)
    x_dot_index = s - 1000*theta_index - 100*x_index - 10*theta_dot_index
    
    if theta_index < 1 or theta_index > 6 or x_index < 1 or x_index > 3 or theta_dot_index < 1 or theta_dot_index > 3 \
        or x_dot_index < 1 or x_dot_index > 3: 
            continue
        
    point_index = at_which_point(s)
    point_array = np.array(point_index)
    point_array = np.append(point_array, value_function[s])
    
    for j in range(5):
        results[i,j] = point_array[j]
    i += 1
    
filtered_results = results[(results[:, 2] == 625*np.pi/180) & (results[:, 3] == 120.25)]

x = filtered_results[:,0]*180/np.pi
y = filtered_results[:,1]
z = filtered_results[:,4]

xi = np.linspace(min(x), max(x), 100)
yi = np.linspace(min(y), max(y), 100)
xi, yi = np.meshgrid(xi, yi)

zi = griddata((x, y), z, (xi, yi), method='cubic')

fig = plt.figure(figsize=(8, 6),dpi=300)
ax = fig.add_subplot(111, projection='3d')
ax.view_init(elev=25, azim=120)

surf = ax.plot_surface(xi, yi, zi, cmap='viridis')
cbar = fig.colorbar(surf, shrink=0.5, aspect=8) 

ax.set_title(r'Value Function ($\dot{\theta}$>50°/s, $\dot{x}$>0.5m/s) (Policy Iteration)', fontsize=14)
ax.set_xlabel(r'Pole Angle $\theta$ (degrees)', fontsize=10)
ax.set_ylabel('Cart Position x (meters)', fontsize=10)
ax.set_zlabel('Value Function', fontsize=10)

plt.tight_layout()
plt.show()

i=0
policy_results = np.zeros((162,5))
for s in range(num_states):
    theta_index = np.floor(s/1000)
    x_index = np.floor((s - 1000*theta_index)/100)
    theta_dot_index = np.floor((s - 1000*theta_index - 100*x_index)/10)
    x_dot_index = s - 1000*theta_index - 100*x_index - 10*theta_dot_index
    
    if theta_index < 1 or theta_index > 6 or x_index < 1 or x_index > 3 or theta_dot_index < 1 or theta_dot_index > 3 \
        or x_dot_index < 1 or x_dot_index > 3: 
            continue

    policy_array = np.array([theta_index,x_index,theta_dot_index,x_dot_index,policy[s]])
    
    for j in range(5):
        policy_results[i,j] = policy_array[j]
    
    i += 1

filtered_results_p = policy_results[(policy_results[:, 2] == 3) & (policy_results[:, 3] == 3)]

optimal_policy = np.zeros((3,6))
for i in range(len(filtered_results_p)):
    xx = filtered_results_p[i,1]-1
    yy = filtered_results_p[i,0]-1
    xx = int(xx)
    yy = int(yy)
    optimal_policy[xx,yy]=filtered_results_p[i,4]

print('Optimal policy:')
print(optimal_policy)

xi = np.linspace(min(x), max(x), 2)
yi = np.linspace(min(y), max(y), 2)
xi, yi = np.meshgrid(xi, yi)


U = np.zeros_like(xi)
V = np.zeros_like(yi)

fig, ax=plt.subplots(figsize=(8, 6),dpi=300)
ax.quiver(xi, yi, U, V, angles='xy', scale_units='xy', scale=0.1)

for i in range(len(filtered_results)):
    x_pos = filtered_results[i,0]*180/np.pi
    y_pos = filtered_results[i,1]
    if filtered_results_p[i,4] == -10:
        x_direct = -1
    else:
        x_direct = 1
    y_direct = 0
    ax.quiver(x_pos, y_pos, x_direct, y_direct, angles='xy', scale_units='xy', scale=1, color='blue')

plt.xlabel('Pole Angle θ (degrees)')
plt.ylabel('Cart Position x (meters)')
plt.title(r'Optimal Policy ($\dot{\theta}$>50°/s, $\dot{x}$>0.5m/s) (Policy Iteration)')

